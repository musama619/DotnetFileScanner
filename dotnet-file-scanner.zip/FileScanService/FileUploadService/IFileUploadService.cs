﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Services.FileUploadService
{
    public interface IFileUploadService
    {
        Task<string> UploadFile(IFormFile file);
    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Models;
using Serilog.Core;
using Services.FileScanService;
using Services.FileValidationService;

namespace Services.FileUploadService
{
    public class FileUploadService(
        IOptions<AttachmentConfiguration> attachmentConfig, 
        IFileScanService fileScanService, 
        IFileValidatorService fileValidatorService,
        ILogger<FileUploadService> logger
        ) : IFileUploadService
    {
        private readonly IOptions<AttachmentConfiguration> _attachmentConfig = attachmentConfig ?? throw new ArgumentNullException(nameof(attachmentConfig));
        private readonly IFileScanService _fileScanService = fileScanService ?? throw new ArgumentNullException(nameof(fileScanService));
        private readonly IFileValidatorService _fileValidatorService = fileValidatorService ?? throw new ArgumentNullException(nameof(fileValidatorService));
        private readonly ILogger<FileUploadService> _logger = logger ?? throw new ArgumentNullException(nameof(logger));


        public async Task<string> UploadFile(IFormFile file)
        {
            _logger.LogInformation("Starting file upload process for file: {FileName}, Size: {FileSize}",
                file.FileName, file.Length);

            // Validate file size
            if (file.Length > _attachmentConfig.Value.MaxFileSize)
            {
                throw new InvalidOperationException("File exceeds maximum allowed size.");
            }

            // Validate file type
            var fileExtension = Path.GetExtension(file.FileName).ToLower();

            if (!_attachmentConfig.Value.AllowedFileTypes.Contains(fileExtension))
            {
                throw new InvalidOperationException("The file type is not allowed for upload.");
            }

            byte[] fileBytes = null;
            using (var memoryStream = new MemoryStream())
            {
                await file.CopyToAsync(memoryStream);
                fileBytes = memoryStream.ToArray();
            }

            // Step 5: Validate the file (e.g., checking the signature)
            if (!_fileValidatorService.Validate(fileBytes, file.FileName))
            {
                throw new InvalidOperationException("The file failed validation checks.");
            }

            var uniqueFileName = Guid.NewGuid().ToString() + fileExtension;

            // Step 4: Save the file temporarily
            string tempPath = Path.Combine(_attachmentConfig.Value.TemporaryPath, uniqueFileName);

            try
            {
                await using (var tempFileStream = new FileStream(tempPath, FileMode.Create))
                {
                    await file.CopyToAsync(tempFileStream);
                }

                var scanResult = await _fileScanService.ScanAsync(tempPath);

                switch (scanResult)
                {
                    case FileScanResult.ThreatFound:
                        throw new InvalidOperationException("The uploaded file contains a potential security threat and cannot be processed further.");
                    case FileScanResult.NoThreatFound:
                        string permanentPath = Path.Combine(_attachmentConfig.Value.AttachmentPath, uniqueFileName);
                        File.Move(tempPath, permanentPath);
                        return uniqueFileName;
                    case FileScanResult.FileNotFound:
                        throw new FileNotFoundException("File not found", uniqueFileName);
                    default:
                        throw new InvalidOperationException("An unexpected error occurred while processing the file.");
                }
            }
            finally
            {
                if (File.Exists(tempPath))
                {
                    File.Delete(tempPath);
                }
            }
        }
    }

}

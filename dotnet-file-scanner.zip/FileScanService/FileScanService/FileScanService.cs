﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Models;
using System.Diagnostics;

namespace Services.FileScanService
{
    public class FileScanService(IOptions<ScannerConfiguration> scannerConfiguration, ILogger<FileScanService> logger) : IFileScanService
    {
        private readonly IOptions<ScannerConfiguration> _scannerConfiguration = scannerConfiguration ?? throw new ArgumentNullException(nameof(scannerConfiguration));
        private readonly ILogger<FileScanService> _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        public async Task<FileScanResult> ScanAsync(string file, int timeoutInMs = 30000)
        {
            _logger.LogInformation("Starting asynchronous file scan for: {File}", file);

            if (!File.Exists(_scannerConfiguration.Value.ScannerPath))
            {
                _logger.LogError("Scanner executable not found at path: {Path}", _scannerConfiguration.Value.ScannerPath);
                throw new FileNotFoundException("Scanner executable not found.", _scannerConfiguration.Value.ScannerPath);
            }

            if (!File.Exists(file))
            {
                _logger.LogError("File to scan not found: {File}", file);
                return FileScanResult.FileNotFound;
            }

            var processStartInfo = new ProcessStartInfo(_scannerConfiguration.Value.ScannerPath,
                _scannerConfiguration.Value.ScannerCommand.Replace("{FilePath}", new FileInfo(file).FullName))
            {
                CreateNoWindow = true,
                ErrorDialog = false,
                WindowStyle = ProcessWindowStyle.Hidden,
                UseShellExecute = false,
            };

            using (var process = new Process { StartInfo = processStartInfo })
            {
                try
                {
                    process.Start();
                    _logger.LogInformation("Scanner process started for: {File}", file);

                    var processExitedSuccessfully = await Task.Run(() => process.WaitForExit(timeoutInMs));
                    if (!processExitedSuccessfully || !process.HasExited)
                    {
                        _logger.LogWarning("Scanner process timed out for: {File}", file);
                        process.Kill();
                        return FileScanResult.Timeout;
                    }

                    _logger.LogInformation("Scanner process exited for: {File} with ExitCode: {ExitCode}", file, process.ExitCode);
                    switch (process.ExitCode)
                    {
                        case 0:
                            return FileScanResult.NoThreatFound;
                        case 2:
                            return FileScanResult.ThreatFound;
                        default:
                            return FileScanResult.Error;
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "An error occurred while scanning the file: {File}", file);
                    return FileScanResult.Error;
                }
            }
        }
    }
}

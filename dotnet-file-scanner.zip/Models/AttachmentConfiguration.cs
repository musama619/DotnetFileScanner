﻿namespace Models
{
    public class AttachmentConfiguration
    {
        public required string AttachmentPath { get; set; }
        public required string TemporaryPath { get; set; }
        public int MaxFileSize { get; set; }
        public required List<string> AllowedFileTypes { get; set; }
    }
}

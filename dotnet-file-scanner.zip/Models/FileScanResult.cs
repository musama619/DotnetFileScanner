﻿using System.ComponentModel;

namespace Models
{
    public enum FileScanResult
    {
        [Description("No threat found")]
        NoThreatFound = 1,

        [Description("Threat found")]
        ThreatFound = 2,

        [Description("The file could not be found")]
        FileNotFound = 3,

        [Description("Timeout")]
        Timeout = 4,

        [Description("Error")]
        Error = 5

    }
}

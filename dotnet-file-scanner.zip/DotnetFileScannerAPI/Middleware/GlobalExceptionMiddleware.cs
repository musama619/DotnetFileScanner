﻿using System.Net;
using System.Security;
using System.Text.Json;

namespace DotnetFileScannerAPI.Middleware
{
    public class GlobalExceptionMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<GlobalExceptionMiddleware> _logger;

        public GlobalExceptionMiddleware(RequestDelegate next, ILogger<GlobalExceptionMiddleware> logger)
        {
            _next = next ?? throw new ArgumentNullException(nameof(next));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unhandled exception occurred");
                await HandleExceptionAsync(context, ex);
            }
        }

        private static async Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            context.Response.ContentType = "application/json";

            var errorResponse = new ErrorResponse
            {
                TraceId = context.TraceIdentifier
            };

            switch (exception)
            {
                case ArgumentException _:
                    context.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                    errorResponse.Title = "Invalid Request";
                    errorResponse.Detail = exception.Message;
                    break;

                case InvalidOperationException _:
                    context.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                    errorResponse.Title = "Operation Error";
                    errorResponse.Detail = exception.Message;
                    break;

                case SecurityException _:
                    context.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                    errorResponse.Title = "Security Error";
                    errorResponse.Detail = exception.Message;
                    break;

                case FileNotFoundException _:
                    context.Response.StatusCode = (int)HttpStatusCode.NotFound;
                    errorResponse.Title = "File Not Found";
                    errorResponse.Detail = exception.Message;
                    break;

                case UnauthorizedAccessException _:
                    context.Response.StatusCode = (int)HttpStatusCode.Forbidden;
                    errorResponse.Title = "Access Denied";
                    errorResponse.Detail = "You do not have permission to perform this operation.";
                    break;

                default:
                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    errorResponse.Title = "Server Error";
                    errorResponse.Detail = "An unexpected error occurred. Please try again later.";
                    break;
            }

            var json = JsonSerializer.Serialize(errorResponse);
            await context.Response.WriteAsync(json);
        }
    }

    public class ErrorResponse
    {
        public string Title { get; set; }
        public string Detail { get; set; }
        public string TraceId { get; set; }
        public int Status { get; set; }
    }
}
